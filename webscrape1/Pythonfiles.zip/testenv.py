from bs4 import BeautifulSoup as bs
import requests

site = requests.get("https://www.clubdeluxe.co/calendar")
soup = bs(site.content, 'lxml')
item = soup.find('a', class_="item-link")
print(item)
print(soup)