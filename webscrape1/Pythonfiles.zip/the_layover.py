import bs4 as bs
import requests
import arrow
import csv
import pandas as pd

def thelayover():
  venue = "The Layover"
  prices = "NaN"

  site_url = "https://www.oaklandlayover.com/calendar"
  site = requests.get(site_url)
  soup = bs.BeautifulSoup(site.content, 'lxml')
  urls = soup.find_all(class_="event_details no-pjax bg-highlight")

  year = (soup.find(class_="month-name")).text
  year = year.split(" ")
  year = year[-1]
  
  external_urls = []
  for url in urls:
    url = url.get('href')
    modified_url = site_url.replace("/calendar", "")
    url = modified_url + url
    external_urls.append(url)
  
  events = []
  times = []
  dates = []
  for url in external_urls:
    site = requests.get(url)
    soup = bs.BeautifulSoup(site.content, 'lxml')
    event = (soup.find(class_="event-info event-title heading-tertiary")).text
    event = event.replace(")", "")
    event = event.split("(")
    final_event = event[0]
    events.append(final_event)
    
    time = event[-1]
    times.append(time)

    date = (soup.find(class_="date")).text
    date = date.split(",")
    date = date[-1]
    date = date.lstrip()
    date = date + " " + year
    date = arrow.get(date, "MMMM D YYYY").format("MM/DD/YY")
    dates.append(date)

  t = ""
  # tries to read csv, if not creates or empty them headers are added
  try:
      df = pd.read_csv('timetable.csv')
  except FileNotFoundError:
      t = "NaN"
  except pd.errors.EmptyDataError:
      t = 'NaN'
  if t == 'NaN':
      with open('timetable.csv', 'w') as ttable:
          filewriter = csv.writer(ttable)
          filewriter.writerow(["Venue", "Event", "Date", "Time", "Price"])
  # Appends all of the elements in our lists to the csv
  with open('timetable.csv', 'a') as ttable:
      filewriter = csv.writer(ttable)
      for i in range(0, len(dates)):
          filewriter.writerow([venue, events[i], dates[i], times[i], prices])

thelayover()
